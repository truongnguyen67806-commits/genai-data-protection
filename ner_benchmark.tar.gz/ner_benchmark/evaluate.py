"""Đánh giá một backend NER trên tập dev JSONL của nhóm.
Chỉ số: Precision/Recall/F1 mức thực thể (so khớp chặt = đúng ranh giới + nhãn;
so khớp lỏng = chồng lấn + đúng nhãn), tính theo từng nhãn, micro, và thời gian xử lý.
Ví dụ: python evaluate.py --data data/dev.jsonl --backend underthesea --out results/underthesea
"""
import argparse, json, time, statistics, csv, unicodedata, os
from collections import defaultdict

NER_SCOPE = ["PERSON_NAME", "ADDRESS"]   # nhãn mà NER thông thường có thể trả về

def load(path):
    with open(path, encoding="utf-8") as f:
        return [json.loads(l) for l in f if l.strip()]

def overlap(a, b):
    return a["start"] < b["end"] and b["start"] < a["end"]

def match(gold, pred, lenient):
    """Ghép 1-1 theo nhãn; trả (tp, fp, fn) theo nhãn."""
    c = defaultdict(lambda: [0, 0, 0])
    used = set()
    for g in gold:
        hit = None
        for i, p in enumerate(pred):
            if i in used or p["label"] != g["label"]:
                continue
            ok = overlap(g, p) if lenient else (g["start"], g["end"]) == (p["start"], p["end"])
            if ok:
                hit = i; break
        if hit is None: c[g["label"]][2] += 1
        else: used.add(hit); c[g["label"]][0] += 1
    for i, p in enumerate(pred):
        if i not in used: c[p["label"]][1] += 1
    return c

def prf(tp, fp, fn):
    p = tp / (tp + fp) if tp + fp else 0.0
    r = tp / (tp + fn) if tp + fn else 0.0
    f = 2 * p * r / (p + r) if p + r else 0.0
    return p, r, f

def summarize(counts, labels):
    rows = {}
    tot = [0, 0, 0]
    for lab in labels:
        tp, fp, fn = counts.get(lab, [0, 0, 0])
        rows[lab] = dict(zip(("P", "R", "F1"), prf(tp, fp, fn)), TP=tp, FP=fp, FN=fn,
                         support=tp + fn)
        tot = [tot[0] + tp, tot[1] + fp, tot[2] + fn]
    rows["MICRO"] = dict(zip(("P", "R", "F1"), prf(*tot)), TP=tot[0], FP=tot[1], FN=tot[2],
                         support=tot[0] + tot[2])
    return rows

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--backend", required=True, help="underthesea | hf:<model> | dummy")
    ap.add_argument("--out", required=True, help="tiền tố tệp kết quả")
    ap.add_argument("--warmup", type=int, default=3)
    a = ap.parse_args()

    from backends import get_backend
    run = get_backend(a.backend)
    import platform

    data = load(a.data)
    for d in data:
        d["text"] = unicodedata.normalize("NFC", d["text"])
    bad = [d["id"] for d in data for x in d["entities"] if d["text"][x["start"]:x["end"]] != x.get("text", d["text"][x["start"]:x["end"]])]
    if bad: raise SystemExit(f"Offset không khớp text ở mẫu: {sorted(set(bad))[:10]}  (kiểm tra NFC/offset)")
    for d in data[:a.warmup]:
        run(d["text"])           # khởi động, không tính giờ

    preds, times = [], []
    for d in data:
        t0 = time.perf_counter(); p = run(d["text"]); times.append((time.perf_counter() - t0) * 1000)
        preds.append(p)

    all_labels = sorted({e["label"] for d in data for e in d["entities"]} | set(NER_SCOPE))
    res = {"backend": a.backend, "n_samples": len(data), "machine": platform.platform(),
           "python": platform.python_version(), "cpu_count": os.cpu_count()}
    for mode, lenient in (("strict", False), ("lenient", True)):
        cnt = defaultdict(lambda: [0, 0, 0])
        for d, p in zip(data, preds):
            for lab, v in match(d["entities"], p, lenient).items():
                for k in range(3): cnt[lab][k] += v[k]
        res[mode + "_all_labels"] = summarize(cnt, all_labels)
        res[mode + "_ner_scope"] = summarize(cnt, NER_SCOPE)

    # mức câu: báo nhầm trên mẫu không nhạy cảm, bỏ sót trên mẫu high (chỉ tính nhãn trong NER_SCOPE)
    neg = [(d, p) for d, p in zip(data, preds) if not d["entities"]]
    res["false_alarm_rate_on_negatives"] = (sum(1 for _, p in neg if p) / len(neg)) if neg else None
    high = [(d, p) for d, p in zip(data, preds) if d.get("risk_level") == "high"]
    res["n_negative"], res["n_high"] = len(neg), len(high)

    s = sorted(times)
    res["time_ms"] = {"mean": statistics.mean(times), "median": statistics.median(times),
                      "p95": s[int(0.95 * (len(s) - 1))], "total_s": sum(times) / 1000}
    # lỗi chi tiết để phân tích
    errs = []
    for d, p in zip(data, preds):
        g = {(e["start"], e["end"], e["label"]) for e in d["entities"] if e["label"] in NER_SCOPE}
        q = {(e["start"], e["end"], e["label"]) for e in p}
        for x in g - q: errs.append(dict(id=d["id"], type="FN", span=x, text=d["text"][x[0]:x[1]]))
        for x in q - g: errs.append(dict(id=d["id"], type="FP", span=x, text=d["text"][x[0]:x[1]]))

    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    json.dump(res, open(a.out + ".json", "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    json.dump(errs, open(a.out + "_errors.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    with open(a.out + ".csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f); w.writerow(["mode", "label", "P", "R", "F1", "TP", "FP", "FN", "support"])
        for key in ("strict_all_labels", "lenient_all_labels"):
            for lab, r in res[key].items():
                w.writerow([key, lab] + [round(r[k], 4) if k in "PRF1" and isinstance(r[k], float) else r[k]
                                         for k in ("P", "R", "F1", "TP", "FP", "FN", "support")])
    m = res["strict_ner_scope"]["MICRO"]; l = res["lenient_ner_scope"]["MICRO"]
    print(f"{a.backend}: strict P/R/F1(NER scope)={m['P']:.3f}/{m['R']:.3f}/{m['F1']:.3f} | "
          f"lenient F1={l['F1']:.3f} | false-alarm(neg)={res['false_alarm_rate_on_negatives']} | "
          f"{res['time_ms']['mean']:.1f} ms/prompt")

if __name__ == "__main__":
    main()
