"""Kiểm thử offline bộ đánh giá (không cần mô hình): python tests_offline.py"""
from evaluate import match, prf, overlap
G=[{"start":0,"end":5,"label":"PERSON_NAME"},{"start":10,"end":20,"label":"ADDRESS"}]
def tot(c): return [sum(v[i] for v in c.values()) for i in range(3)]
# đúng hoàn toàn
assert tot(match(G,[dict(x) for x in G],False))==[2,0,0]
# lệch ranh giới: chặt = 0 TP, lỏng = 1 TP với ADDRESS
P=[{"start":0,"end":5,"label":"PERSON_NAME"},{"start":14,"end":20,"label":"ADDRESS"}]
assert tot(match(G,P,False))==[1,1,1] and tot(match(G,P,True))==[2,0,0]
# sai nhãn không khớp
assert tot(match(G[:1],[{"start":0,"end":5,"label":"ADDRESS"}],True))==[0,1,1]
# một dự đoán không được ghép cho 2 gold
assert tot(match([G[0],dict(G[0])],[G[0]],True))==[1,0,1]
assert prf(0,0,0)==(0,0,0)
print("OK: 5 kiểm thử đạt")
