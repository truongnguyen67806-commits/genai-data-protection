# Thành viên 2 – Khảo sát & thử nghiệm NER tiếng Việt (so với Underthesea)

## Chạy nhanh
```bash
pip install -r requirements.txt
bash run_all.sh data/dev.jsonl            # thêm tham số 2 để thử mô hình thứ hai: hf:<tên>
```

## Chạy từng bước (cần Internet để tải model)
```bash
pip install -r requirements.txt
# đặt tập dev của nhóm (JSONL) vào data/dev.jsonl
python evaluate.py --data data/dev.jsonl --backend underthesea                         --out results/underthesea
python evaluate.py --data data/dev.jsonl --backend hf:NlpHUST/ner-vietnamese-electra-base --out results/electra
python compare.py results/underthesea.json results/electra.json   # bảng kết quả (Markdown + results/comparison.csv)
```
`python tests_offline.py` kiểm thử bộ đánh giá không cần mô hình. Bộ đánh giá dừng nếu `text[start:end]` lệch với `text` của thực thể (lỗi NFC/offset).
Tệp `results/*_errors.json` liệt kê FP/FN từng câu để viết phần phân tích lỗi.

## Cách đánh giá
- Mức thực thể. **Chặt** = đúng start/end và nhãn; **lỏng** = chồng lấn và đúng nhãn.
- NER có sẵn chỉ trả PER/LOC/ORG/MISC nên chỉ ánh xạ được **PERSON_NAME** (PER) và **ADDRESS** (LOC).
  Vì vậy báo cáo hai phạm vi: *PERSON_NAME+ADDRESS* (so sánh công bằng) và *10 nhãn* (Recall bị chặn trên, vì 8 nhãn còn lại thuộc Regex).
- LOC thường chỉ bắt "Hải Phòng", trong khi nhãn ADDRESS là cả "số 12 đường…, Hải Phòng" -> so khớp chặt thấp là bình thường, xem thêm so khớp lỏng.
- Thời gian: ms/prompt trung bình, trung vị, p95 trên CPU, sau 3 câu khởi động. Ghi cấu hình máy vào báo cáo.
- Báo nhầm: % mẫu không có thực thể mà mô hình vẫn trả thực thể.
- Ánh xạ nhãn sửa ở `backends.py` (`LABEL_MAP`). Không thay đổi code NER chính của nhóm.

## Ứng viên mô hình
1. `NlpHUST/ner-vietnamese-electra-base` – ELECTRA tinh chỉnh trên VLSP 2018, nhãn Person/Location/Organization/Miscellaneous, F1 báo cáo 0,92 trên tập VLSP (miền báo chí, không phải tập của nhóm); trang mô hình không nêu giấy phép -> kiểm tra trước khi dùng lâu dài.
2. Mô hình thứ hai (chọn 1): PhoBERT tinh chỉnh NER trên Hub (cần kiểm tra nhãn/giấy phép), hoặc VnCoreNLP/PhoNLP nếu cài được. Thêm bằng `--backend hf:<tên>`.

## Mẫu bảng bàn giao (điền sau khi chạy – chưa có số liệu thật)
| Phương pháp | Phạm vi | So khớp | P | R | F1 | Báo nhầm | ms/prompt | p95 ms |
|---|---|---|---|---|---|---|---|---|
| Underthesea | PERSON_NAME+ADDRESS | chặt/lỏng | | | | | | |
| NlpHUST ELECTRA | PERSON_NAME+ADDRESS | chặt/lỏng | | | | | | |

Nhắc lại: chỉ dùng dữ liệu giả lập/đã ẩn danh; làm trên nhánh GitHub riêng (vd. `ner-khao-sat`).
