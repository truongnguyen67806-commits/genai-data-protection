#!/usr/bin/env bash
# Chạy toàn bộ so sánh trên tập dev của nhóm. Cần Internet lần đầu để tải mô hình.
# Dùng: bash run_all.sh [data/dev.jsonl] [hf:model_thu_hai]
set -e
DATA=${1:-data/dev.jsonl}
M2=${2:-}
python tests_offline.py
python evaluate.py --data "$DATA" --backend underthesea --out results/underthesea
python evaluate.py --data "$DATA" --backend hf:NlpHUST/ner-vietnamese-electra-base --out results/electra
FILES="results/underthesea.json results/electra.json"
if [ -n "$M2" ]; then
  python evaluate.py --data "$DATA" --backend "$M2" --out results/model2; FILES="$FILES results/model2.json"
fi
python compare.py $FILES | tee results/comparison.md
