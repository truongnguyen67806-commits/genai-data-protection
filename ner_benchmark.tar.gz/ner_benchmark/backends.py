"""Các backend NER. Mỗi backend là hàm: text -> list[dict(start,end,label)].
Nhãn mô hình được ánh xạ về nhãn v1.0 của nhóm (chỉ PERSON_NAME và ADDRESS)."""
import re

# Ánh xạ nhãn NER chung -> nhãn v1.0. Chỉnh tại đây nếu muốn thử ánh xạ khác.
LABEL_MAP = {
    "PER": "PERSON_NAME", "PERSON": "PERSON_NAME",
    "LOC": "ADDRESS", "LOCATION": "ADDRESS",
}

def _norm(tag):
    t = re.sub(r"^[BIES]-", "", tag.upper())
    return LABEL_MAP.get(t)  # None -> bỏ (ORG, MISC...)


def underthesea_backend():
    from underthesea import ner
    def run(text):
        spans, cur, cursor = [], None, 0
        for tok in ner(text):
            word, tag = tok[0], tok[-1]
            word = word.replace("_", " ") if word not in text else word
            pos = text.find(word, cursor)
            if pos < 0:          # không căn được token -> bỏ qua
                continue
            s, e, cursor = pos, pos + len(word), pos + len(word)
            lab = _norm(tag) if tag != "O" else None
            if lab and (tag.startswith("B-") or cur is None or cur["label"] != lab):
                cur = {"start": s, "end": e, "label": lab}; spans.append(cur)
            elif lab:
                cur["end"] = e
            else:
                cur = None
        return spans
    return run


def hf_backend(model_name, device=-1):
    from transformers import pipeline
    nlp = pipeline("token-classification", model=model_name, device=device,
                   aggregation_strategy="simple")
    def run(text):
        out = []
        for r in nlp(text):
            lab = _norm(r["entity_group"])
            if not lab:
                continue
            s, e = int(r["start"]), int(r["end"])
            while s < e and text[s].isspace(): s += 1      # bỏ khoảng trắng đầu/cuối span
            while e > s and text[e - 1].isspace(): e -= 1
            if e > s:
                out.append({"start": s, "end": e, "label": lab})
        return out
    return run


def dummy_backend():
    """Backend giả để kiểm thử bộ đánh giá, không cần mô hình."""
    def run(text):
        i = text.find("Lê Văn Hùng")
        return [{"start": i, "end": i + 11, "label": "PERSON_NAME"}] if i >= 0 else []
    return run


def get_backend(name):
    if name == "dummy":
        return dummy_backend()
    if name == "underthesea":
        return underthesea_backend()
    if name.startswith("hf:"):
        return hf_backend(name[3:])
    raise ValueError(f"backend không hợp lệ: {name}  (underthesea | hf:<tên-model>)")
