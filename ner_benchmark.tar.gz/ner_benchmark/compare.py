"""Gộp các tệp results/*.json thành bảng so sánh Markdown + CSV.  python compare.py results/*.json"""
import json, sys, csv
rs = [json.load(open(p, encoding="utf-8")) for p in sys.argv[1:] if p.endswith(".json") and not p.endswith("_errors.json")]
hdr = ["Phương pháp", "Phạm vi", "So khớp", "P", "R", "F1", "Báo nhầm (mẫu âm)", "ms/prompt (TB)", "p95 ms"]
rows = []
for r in rs:
    for scope, name in (("ner_scope", "PERSON_NAME+ADDRESS"), ("all_labels", "10 nhãn")):
        for mode in ("strict", "lenient"):
            m = r[f"{mode}_{scope}"]["MICRO"]
            rows.append([r["backend"], name, "chặt" if mode == "strict" else "lỏng",
                         f"{m['P']:.3f}", f"{m['R']:.3f}", f"{m['F1']:.3f}",
                         f"{r['false_alarm_rate_on_negatives']:.1%}" if r["false_alarm_rate_on_negatives"] is not None else "-",
                         f"{r['time_ms']['mean']:.1f}", f"{r['time_ms']['p95']:.1f}"])
w = csv.writer(open("results/comparison.csv", "w", newline="", encoding="utf-8")); w.writerow(hdr); w.writerows(rows)
print("| " + " | ".join(hdr) + " |\n|" + "---|" * len(hdr))
for x in rows: print("| " + " | ".join(x) + " |")
