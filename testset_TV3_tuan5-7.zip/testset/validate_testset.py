#!/usr/bin/env python3
"""Rà soát tự động bộ kiểm thử: offset, ranh giới, nhãn, mức rủi ro, trùng lặp, an toàn dữ liệu.

Chạy:
  python validate_testset.py data/testset_independent.jsonl
  python validate_testset.py data/testset_independent.jsonl --old dataset_nhay_cam_vi.jsonl --blocklist blocklist.txt

Mã thoát: 0 nếu không có LỖI (cảnh báo vẫn có thể có); 1 nếu có lỗi.
--old        bộ dữ liệu v1.0 của nhóm, để kiểm tra "không sao chép dữ liệu cũ"
--blocklist  tệp mỗi dòng một chuỗi không được xuất hiện (họ tên, SĐT, email thật của thành viên/giảng viên...)
"""
import argparse, json, re, sys, unicodedata
from collections import Counter, defaultdict

from common import (LABELS, REVIEW_STATUSES, RISK_LEVELS, SCENARIOS, compute_risk,
                    mask_template, read_jsonl)

ERRORS, WARNINGS = [], []


def err(sid, msg):
    ERRORS.append((sid, msg))


def warn(sid, msg):
    WARNINGS.append((sid, msg))


RESERVED_DOMAIN = re.compile(r"(?:^|\.)(?:example\.(?:com|org|net)|example|test|invalid|localhost)$", re.I)
EMAIL_RE = re.compile(r"[\w.+\-]+@([\w\-]+(?:\.[\w\-]+)+)")
LEADING_KEYWORD = re.compile(r"^(?:MSSV|SĐT|SDT|CCCD|CMND|STK|TK|mật khẩu|password|pass|pwd|API_KEY|TOKEN|OTP|PIN)\s*[:=]", re.I)
HONORIFIC = re.compile(r"^(?:ThS|TS|PGS\.TS|PGS|GS|thầy|cô|bạn|em|anh|chị|sinh viên|SV)\b[\s.]", re.I)
TRAILING_PUNCT = re.compile(r"[.,;:!?)\]'\"]$")

# Giá trị lấy từ chính tài liệu Tuần 1–4 (ví dụ minh họa): không được dùng lại trong bộ độc lập
DOC_EXAMPLES = [
    "Lê Văn Hùng", "Trần Minh Long", "2512345678", "0912 345 678", "012345678901", "0123456789012",
    "Hpu@2026", "sk-Ab12Cd34Ef56Gh78", "ten.ho@example.edu.vn", "Lạch Tray", "CT250123",
    "nguyen.van.an@example.com", "Nguyen Van Hung", "bạn Lan",
]

CANDIDATES = {
    "phone": re.compile(r"(?<![\d])(?:\+84|84|0)(?:[\s.\-]?\d){9}(?!\d)"),
    "email": EMAIL_RE,
    "digits_9_14": re.compile(r"(?<![\d])\d{9,14}(?!\d)"),
    "digits_grouped": re.compile(r"(?<!\d)\d{3,4}(?:[ .]\d{3,4}){2,3}(?!\d)"),
    "token_like": re.compile(r"(?<![\w])(?:sk[-_]|ghp_|xox[bp]-|AKIA|AIza|eyJ|tok_)\w[\w\-.#$@]{8,}"),
}


def check_format(sid, e, strict):
    lab, v = e["label"], e["text"]
    flat = re.sub(r"[ .\-]", "", v)
    report = err if strict else warn
    if lab == "STUDENT_ID" and not (re.fullmatch(r"\d{10}", v) or re.fullmatch(r"\d{8}", v) or re.fullmatch(r"[A-Za-z]{2}\d{6}", v)):
        report(sid, f"STUDENT_ID '{v}' không thuộc 3 dạng v1.0 (10 số; 8 số; 2 chữ + 6 số)")
    if lab == "PHONE" and not re.fullmatch(r"(?:\+84|84|0)\d{9}", flat):
        report(sid, f"PHONE '{v}' không khớp dạng số di động VN")
    if lab == "EMAIL":
        m = EMAIL_RE.fullmatch(v)
        if not m:
            report(sid, f"EMAIL '{v}' không đúng dạng tên@miền")
        elif not RESERVED_DOMAIN.search(m.group(1)):
            err(sid, f"EMAIL '{v}' dùng tên miền không nằm trong nhóm dành riêng (example.*, .example, .test…)")
    if lab == "NATIONAL_ID" and not (flat.isdigit() and len(flat) in (9, 12)):
        report(sid, f"NATIONAL_ID '{v}' không phải CMND 9 số hoặc CCCD 12 số")
    if lab == "BANK_ACCOUNT" and not (flat.isdigit() and 9 <= len(flat) <= 14):
        report(sid, f"BANK_ACCOUNT '{v}' không phải 9–14 chữ số")
    if lab == "CREDENTIAL" and (not v or " " in v):
        warn(sid, f"CREDENTIAL '{v}' chứa khoảng trắng hoặc rỗng, kiểm tra lại ranh giới")
    if lab == "SECRET_KEY" and len(v) < 16:
        warn(sid, f"SECRET_KEY '{v}' ngắn (<16 ký tự)")
    if lab == "PERSON_NAME":
        if re.search(r"\d|@", v):
            report(sid, f"PERSON_NAME '{v}' chứa chữ số hoặc @")
        if len(v.split()) > 5:
            warn(sid, f"PERSON_NAME '{v}' dài hơn 5 âm tiết")
    if lab == "ACADEMIC_RECORD" and len(v.split()) < 2:
        warn(sid, f"ACADEMIC_RECORD '{v}' chỉ có một từ")
    if lab == "ADDRESS" and "," not in v and len(v.split()) < 4:
        warn(sid, f"ADDRESS '{v}' ngắn, có thể chưa đủ cụm địa chỉ")


def check_boundary(sid, text, e):
    lab, v, s, t = e["label"], e["text"], e["start"], e["end"]
    if v != v.strip():
        err(sid, f"Span '{v}' có khoảng trắng ở đầu/cuối")
    if LEADING_KEYWORD.match(v):
        err(sid, f"Span '{v}' lấy cả từ khóa dẫn")
    if lab == "PERSON_NAME" and HONORIFIC.match(v + " "):
        err(sid, f"Span '{v}' lấy cả xưng hô/chức danh")
    if lab not in ("CREDENTIAL", "SECRET_KEY") and TRAILING_PUNCT.search(v):
        err(sid, f"Span '{v}' kết thúc bằng dấu câu")
    # cắt giữa token: ký tự liền kề là chữ/số
    if lab in ("STUDENT_ID", "PHONE", "NATIONAL_ID", "BANK_ACCOUNT", "EMAIL"):
        if s > 0 and (text[s - 1].isalnum() or text[s - 1] in "_"):
            warn(sid, f"Span '{v}' có ký tự chữ/số ngay trước nó ('{text[s-1]}'): có thể bị cắt giữa token")
        if t < len(text) and (text[t].isalnum() or text[t] == "_"):
            warn(sid, f"Span '{v}' có ký tự chữ/số ngay sau nó ('{text[t]}'): có thể bị cắt giữa token")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("path")
    ap.add_argument("--old", help="bộ dữ liệu cũ (jsonl) để kiểm tra tính độc lập")
    ap.add_argument("--blocklist", help="tệp chuỗi không được xuất hiện")
    ap.add_argument("--min-per-label", type=int, default=12)
    ap.add_argument("--report-json", help="ghi kết quả ra json")
    args = ap.parse_args()

    recs = read_jsonl(args.path)
    ids = Counter(r["id"] for r in recs)
    texts = Counter(r["text"] for r in recs)
    templates = defaultdict(list)
    lab_count = Counter()
    n_checked = 0

    for r in recs:
        sid = r.get("id", "?")
        strict = r.get("review_status") != "REVIEW_REQUIRED"
        for k in ("id", "split", "scenario", "template_id", "text", "entities", "risk_level", "has_sensitive", "no_diacritics"):
            if k not in r:
                err(sid, f"Thiếu trường '{k}'")
        if ids[sid] > 1:
            err(sid, "ID trùng")
        if r["scenario"] not in SCENARIOS:
            err(sid, f"scenario '{r['scenario']}' ngoài danh mục")
        if r["risk_level"] not in RISK_LEVELS:
            err(sid, f"risk_level '{r['risk_level']}' không hợp lệ")
        if r.get("review_status", "LABELED") not in REVIEW_STATUSES:
            err(sid, f"review_status '{r.get('review_status')}' không hợp lệ")
        text = r["text"]
        if text != unicodedata.normalize("NFC", text):
            err(sid, "Văn bản chưa chuẩn hóa NFC")
        if "\r" in text or any(unicodedata.category(c) == "Cc" and c not in "\n\t" for c in text):
            err(sid, "Có ký tự điều khiển lạ")
        if texts[text] > 1:
            err(sid, "Văn bản trùng với mẫu khác")

        ents = sorted(r["entities"], key=lambda e: (e["start"], e["end"]))
        if r["has_sensitive"] != bool(ents):
            err(sid, "has_sensitive không khớp với entities")
        if compute_risk(ents) != r["risk_level"]:
            err(sid, f"risk_level={r['risk_level']} nhưng quy tắc Bảng 10 cho {compute_risk(ents)}")

        prev_end = -1
        for e in ents:
            n_checked += 1
            if e["label"] not in LABELS:
                err(sid, f"Nhãn '{e['label']}' ngoài danh mục 10 nhãn")
                continue
            if not (0 <= e["start"] < e["end"] <= len(text)):
                err(sid, f"start/end ngoài phạm vi: {e['start']}–{e['end']}")
                continue
            if text[e["start"]:e["end"]] != e["text"]:
                err(sid, f"text[start:end]='{text[e['start']:e['end']]}' khác entity.text='{e['text']}'")
                continue
            if e["start"] < prev_end:
                err(sid, f"Span chồng lấn tại '{e['text']}'")
            prev_end = max(prev_end, e["end"])
            if strict:
                lab_count[e["label"]] += 1
            check_boundary(sid, text, e) if strict else None
            check_format(sid, e, strict)

        # mỗi lần xuất hiện của giá trị đã gán đều phải được gán
        covered = [(e["start"], e["end"], e["label"]) for e in ents]
        for e in ents:
            if len(e["text"]) < 3:
                continue
            for m in re.finditer(r"(?<!\w)" + re.escape(e["text"]) + r"(?!\w)", text):
                if not any(s <= m.start() and m.end() <= t for s, t, _ in covered):
                    err(sid, f"'{e['text']}' xuất hiện lần nữa tại {m.start()} nhưng chưa được gán")

        # rà bỏ sót: chuỗi giống dữ liệu nhạy cảm nhưng không nằm trong span nào
        tags = set(r.get("difficulty_tags", []))
        expected_negative = bool(tags & {"hard_negative", "log"}) or not strict
        for name, rx in CANDIDATES.items():
            for m in rx.finditer(text):
                if not any(s < m.end() and m.start() < t for s, t, _ in covered):
                    msg = f"Chuỗi giống {name} '{m.group()}' không được gán nhãn"
                    (warn if expected_negative else err)(sid, msg + (" (mẫu khó đã đánh dấu)" if expected_negative else " → có thể bỏ sót"))

        # an toàn dữ liệu
        for m in EMAIL_RE.finditer(text):
            # bỏ qua userinfo trong URL (user:mật_khẩu@máy_chủ, token@github.com): đã nằm trong span CREDENTIAL/SECRET_KEY
            if any(e["label"] in ("CREDENTIAL", "SECRET_KEY") and e["start"] < m.end() and m.start() < e["end"] for e in ents):
                continue
            if not RESERVED_DOMAIN.search(m.group(1)):
                err(sid, f"Email '{m.group()}' dùng tên miền không dành riêng")
        for ex in DOC_EXAMPLES:
            if ex.lower() in text.lower():
                err(sid, f"Có giá trị trùng ví dụ trong tài liệu Tuần 1–4: '{ex}'")
        templates[mask_template(text, ents)].append(sid)

    for tpl, sids in templates.items():
        if len(sids) > 1:
            err(",".join(sids), "Các mẫu trùng khuôn mẫu sau khi che thực thể")

    if args.blocklist:
        block = [l.strip() for l in open(args.blocklist, encoding="utf-8") if l.strip() and not l.startswith("#")]
        for r in recs:
            for b in block:
                if b.lower() in r["text"].lower():
                    err(r["id"], "Chứa chuỗi trong blocklist (nghi dữ liệu thật)")

    if args.old:
        old = read_jsonl(args.old)
        old_texts = {o["text"] for o in old}
        old_tpl = {mask_template(o["text"], o["entities"]) for o in old}
        old_vals = {(e["label"], e["text"].lower()) for o in old for e in o["entities"]}
        for r in recs:
            if r["text"] in old_texts:
                err(r["id"], "Văn bản trùng với bộ dữ liệu cũ")
            if mask_template(r["text"], r["entities"]) in old_tpl:
                err(r["id"], "Khuôn mẫu trùng bộ dữ liệu cũ")
            for e in r["entities"]:
                if (e["label"], e["text"].lower()) in old_vals:
                    warn(r["id"], f"Giá trị '{e['text']}' ({e['label']}) cũng có trong bộ cũ")

    for lab in LABELS:
        if lab_count[lab] < args.min_per_label:
            warn("-", f"Nhãn {lab} chỉ có {lab_count[lab]} thực thể (mục tiêu ≥ {args.min_per_label})")
    n_neg = sum(1 for r in recs if not r["entities"])
    if n_neg / len(recs) < 0.2:
        warn("-", f"Mẫu không chứa thực thể chỉ chiếm {n_neg/len(recs):.0%}")

    print(f"Đã kiểm tra {len(recs)} mẫu, {n_checked} thực thể.")
    print(f"LỖI: {len(ERRORS)}   CẢNH BÁO: {len(WARNINGS)}")
    for sid, m in ERRORS:
        print(f"  [LỖI] {sid}: {m}")
    for sid, m in WARNINGS:
        print(f"  [CẢNH BÁO] {sid}: {m}")
    if args.report_json:
        json.dump({"n_samples": len(recs), "n_entities": n_checked, "errors": ERRORS, "warnings": WARNINGS},
                  open(args.report_json, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    return 1 if ERRORS else 0


if __name__ == "__main__":
    sys.exit(main())
