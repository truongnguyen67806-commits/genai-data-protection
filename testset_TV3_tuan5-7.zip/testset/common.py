"""Hằng số và hàm dùng chung cho bộ kiểm thử độc lập (đề tài phát hiện dữ liệu nhạy cảm khi dùng GenAI).

Nguồn quy ước: "Báo cáo kết quả thực hiện Tuần 1–4" (danh mục 10 nhãn v1.0, Bảng 10 – quy tắc mức rủi ro,
Bảng 13/14 – quy tắc gán nhãn, Mục 2.2.6 – cấu trúc bản ghi và quy ước offset).
"""
import unicodedata

# 10 nhãn v1.0 (không đổi tên nếu chưa được cả nhóm và thầy hướng dẫn thống nhất)
LABELS = [
    "PERSON_NAME", "STUDENT_ID", "PHONE", "EMAIL", "NATIONAL_ID",
    "BANK_ACCOUNT", "CREDENTIAL", "SECRET_KEY", "ACADEMIC_RECORD", "ADDRESS",
]

# Mã viết tắt chỉ dùng khi soạn dữ liệu nguồn: [[PN:Nguyễn Văn X]]
ALIAS = {
    "PN": "PERSON_NAME", "SID": "STUDENT_ID", "PH": "PHONE", "EM": "EMAIL",
    "NID": "NATIONAL_ID", "BA": "BANK_ACCOUNT", "CR": "CREDENTIAL",
    "SK": "SECRET_KEY", "AR": "ACADEMIC_RECORD", "AD": "ADDRESS",
}

SCENARIOS = ["hoc_tap", "hanh_chinh", "cntt"]
RISK_LEVELS = ["none", "low", "medium", "high"]
REVIEW_STATUSES = ["DRAFT", "LABELED", "REVIEWED", "REVIEW_REQUIRED"]

HIGH_LABELS = {"NATIONAL_ID", "BANK_ACCOUNT", "CREDENTIAL", "SECRET_KEY"}
MEDIUM_LABELS = {"PHONE", "EMAIL", "STUDENT_ID", "ADDRESS", "ACADEMIC_RECORD"}


def nfc(s: str) -> str:
    return unicodedata.normalize("NFC", s)


def compute_risk(entities) -> str:
    """Bảng 10: none < low < medium < high; luôn chọn mức cao nhất thỏa điều kiện."""
    if not entities:
        return "none"
    kinds = {e["label"] for e in entities}
    if kinds & HIGH_LABELS:
        return "high"
    if "ACADEMIC_RECORD" in kinds and kinds & {"PERSON_NAME", "STUDENT_ID"}:
        return "high"
    if len(kinds) >= 3 or len(entities) >= 5:
        return "high"
    if kinds & MEDIUM_LABELS:
        return "medium"
    return "low"  # chỉ có PERSON_NAME


def mask_template(text, entities):
    """Thay mỗi thực thể bằng <NHÃN>, dùng để phát hiện câu cùng khuôn mẫu."""
    out, pos = [], 0
    for e in sorted(entities, key=lambda x: x["start"]):
        out.append(text[pos:e["start"]])
        out.append(f"<{e['label']}>")
        pos = e["end"]
    out.append(text[pos:])
    return " ".join("".join(out).lower().split())


def read_jsonl(path):
    import json
    with open(path, encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]
