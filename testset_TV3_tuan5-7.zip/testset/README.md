# Bộ kiểm thử độc lập – Thành viên 3 (Tuần 5–7)

Dữ liệu hoàn toàn giả lập. Không đưa thông tin cá nhân thật, khóa/token/mật khẩu đang hoạt động vào repo.

## Chạy
```bash
python build_testset.py --out data            # sinh data/* từ testset_source.py (tự tính start/end)
python validate_testset.py data/testset_independent.jsonl
python validate_testset.py data/testset_independent.jsonl --old dataset_nhay_cam_vi.jsonl --blocklist blocklist.txt
python compare_annotations.py data/blind_sample_key.jsonl nhan_nguoi_thu_hai.jsonl --csv bat_dong.csv
```
Chỉ cần Python 3, không cần cài thư viện.

## Thêm / sửa mẫu
Sửa `testset_source.py`, dùng cú pháp `[[MÃ:giá trị]]` (PN, SID, PH, EM, NID, BA, CR, SK, AR, AD), chạy lại build và validate.

## Lưu ý
- `data/blind_sample_key.jsonl` chứa nhãn gốc: không đưa cho người gán thứ hai (chỉ đưa `blind_sample.jsonl`).
- Mẫu `review_status = REVIEW_REQUIRED` mang nhãn tạm; loại khỏi tính chỉ số cho đến khi nhóm chốt.
- `blocklist.txt` (nếu dùng) mỗi dòng một chuỗi thật không được xuất hiện; không commit tệp này lên GitHub.
