# -*- coding: utf-8 -*-
"""Dữ liệu nguồn của bộ kiểm thử độc lập (viết tay, toàn bộ là dữ liệu giả lập).

Cú pháp đánh dấu thực thể:  [[MÃ:giá trị]]   với MÃ thuộc PN, SID, PH, EM, NID, BA, CR, SK, AR, AD
  PN=PERSON_NAME  SID=STUDENT_ID  PH=PHONE  EM=EMAIL  NID=NATIONAL_ID
  BA=BANK_ACCOUNT CR=CREDENTIAL   SK=SECRET_KEY  AR=ACADEMIC_RECORD  AD=ADDRESS
Chỉ đánh dấu phần GIÁ TRỊ (không gồm từ khóa như MSSV:, xưng hô, dấu câu cuối).
build_testset.py sẽ tự tính start/end, nên không phải đếm ký tự thủ công.

S(kịch_bản, văn_bản_có_đánh_dấu, tags="", status="LABELED", note="")
  tags: các thẻ cách nhau bởi khoảng trắng. Thẻ "log" đưa mẫu vào nhật ký trường hợp khó.
  status: LABELED hoặc REVIEW_REQUIRED (chưa thống nhất; nhãn trong mẫu chỉ là nhãn tạm).
"""

SAMPLES = []


def S(scenario, markup, tags="", status="LABELED", note=""):
    SAMPLES.append({
        "scenario": scenario, "markup": markup,
        "tags": tags.split(), "status": status, "note": note,
    })


HT, HC, IT = "hoc_tap", "hanh_chinh", "cntt"

# ============================== HỌC TẬP ==============================
S(HT, "Em là [[PN:Đặng Quốc Việt]], MSSV [[SID:2511223344]], lớp CNTT2.K25. Em muốn hỏi cách nộp bài tập lớn môn Mạng máy tính.", "multi_entity class_code")
S(HT, "Nhờ AI tóm tắt giúp báo cáo của bạn [[PN:Phạm Thu Hà]] về cân bằng tải trong hệ thống web.", "honorific")
S(HT, "Bạn [[PN:Thảo]] nhờ mình gửi lại slide, bạn nhắn qua [[EM:thao.pham@mail.example]] giúp mình nhé.", "single_name multi_entity log",
  note="Tên gọi một âm tiết khi chỉ rõ một người: Bảng 14 cho phép (ví dụ 'bạn Lan → Lan') nhưng cũng ghi họ tên 2–4 âm tiết, hai ý chưa khớp nhau.")
S(HT, "Giải thích giúp mình thuật toán Dijkstra khác gì so với Bellman-Ford.", "hard_negative", note="Tên nhà khoa học trong tên thuật toán, không phải người dùng.")
S(HT, "Tóm tắt đóng góp của Alan Turing trong lý thuyết tính toán.", "hard_negative public_figure")
S(HT, "Hãy phân tích nhân vật Thúy Kiều trong Truyện Kiều của Nguyễn Du.", "hard_negative literary")
S(HT, "ban hay giai thich giup toi su khac nhau giua TCP va UDP", "no_diacritics")
S(HT, "em ten la [[PN:nguyen thi mai]], mssv [[SID:2509876543]], em xin hoi lich thi cuoi ky", "no_diacritics multi_entity")
S(HT, "EM LÀ [[PN:TRẦN ĐỨC ANH]], MSSV [[SID:CT250417]], XIN PHÉP NGHỈ HỌC NGÀY 20/11.", "uppercase multi_entity")
S(HT, "Em là sinh viên [[PN:N. V. Khoa]], mã sinh viên [[SID:25104455]], cần hỗ trợ đăng ký học phần.", "abbrev honorific")
S(HT, "Báo cáo nhóm 4 gồm [[PN:Vũ Hải Yến]], [[PN:Đinh Công Minh]] và [[PN:Souphanh Keomany]]. Hãy gợi ý bố cục slide.", "foreign_name")
S(HT, "Sinh viên [[PN:Hoàng Gia Bảo]] [[AR:bị cảnh báo học vụ mức 1]] kỳ này, hãy soạn thư xin gia hạn đóng học phí.", "academic")
S(HT, "Em [[AR:có GPA 2,15]], MSSV [[SID:2511556677]], em nên làm gì để kéo lên 2,5?", "academic multi_entity")
S(HT, "GPA là điểm trung bình tích lũy, được tính theo thang 4 như thế nào?", "hard_negative academic_general")
S(HT, "Em được [[AR:học bổng khuyến khích học tập loại khá]], tên em là [[PN:Lê Thảo Vy]]. Viết giúp bài chia sẻ kinh nghiệm học tập.", "academic")
S(HT, "Cô chủ nhiệm báo em [[AR:bị kỷ luật khiển trách]] vì thi muộn; em là [[PN:Mai Khánh Linh]].", "academic")
S(HT, "Theo quy chế, sinh viên có GPA dưới 2,0 sẽ bị cảnh báo học vụ. Giải thích quy định này giúp mình.", "hard_negative academic_general")
S(HT, "Mẫu đơn: Em tên là [Họ tên], MSSV [MSSV], SĐT [SĐT]. Em xin phép được nghỉ học ngày [ngày].", "hard_negative placeholder")
S(HT, "Liên hệ phòng Đào tạo qua phongdaotao@uni.example hoặc hotline 1900 6868 để được hỗ trợ.", "hard_negative org_contact")
S(HT, "Lớp CNTT4.K25 học môn CS201 vào chiều thứ Ba, mã học phần CS201-02, phòng A3-405.", "hard_negative class_code")
S(HT, "Em là [[PN:Ngô Anh Tuấn]]. Nhờ AI viết lại email sau: 'Kính gửi thầy, em [[PN:Ngô Anh Tuấn]], MSSV [[SID:2512008899]], xin nộp muộn bài tập.'", "repeat quoted multi_entity")
S(HT, "Tổng hợp danh sách nhóm:\n1) [[PN:Phan Văn Tài]] - [[SID:2512340011]]\n2) [[PN:Lý Thu Hằng]] - [[SID:2512340022]]\n3) [[PN:Cao Thị Ngọc]] - [[SID:2512340033]]", "multiline multi_entity")
S(HT, "ho_ten,mssv,email\n[[PN:Đào Xuân Lộc]],[[SID:2513456789]],[[EM:loc.dao@mail.example]]\n[[PN:Tạ Bích Ngân]],[[SID:2513456790]],[[EM:ngan.ta@mail.example]]", "multiline csv multi_entity")
S(HT, "Mã sinh viên gồm 10 chữ số, ví dụ 25xxxxxxxx. Làm sao để kiểm tra mã hợp lệ bằng Excel?", "hard_negative placeholder")
S(HT, "Thang điểm chữ A, B+, B, C+, C, D, F quy đổi sang thang 4 như thế nào?", "hard_negative academic_general")
S(HT, "Năm nay khoa có 120 sinh viên bị cảnh báo học vụ, hãy vẽ biểu đồ tỷ lệ theo ngành.", "hard_negative academic_general")
S(HT, "Bạn [[PN:Lục Hải Đăng]] [[AR:có điểm rèn luyện xếp loại yếu]], giúp mình soạn đơn khiếu nại.", "academic log",
  note="Span ACADEMIC_RECORD có gồm động từ 'có/bị/được' hay không chưa được quy định (Bảng 13 nói span chỉ gồm giá trị, Bảng 15 lại gán cả cụm 'bị cảnh báo học vụ mức 2').")
S(HT, "[[SID:2511101010]] [[AR:bị cảnh báo học vụ mức 2]], nhờ AI soạn đơn xin bảo lưu kết quả.", "academic")
S(HT, "Anh [[PN:Châu Văn Lâm]] [[AR:bị buộc thôi học]] từ tháng 9, hãy soạn thư động viên.", "academic honorific")
S(HT, "Em [[AR:bị cảnh báo học vụ mức 3]], nên xin nghỉ hay học tiếp?", "academic log", status="REVIEW_REQUIRED",
  note="Không có họ tên/MSSV trong câu. Bảng 14 chỉ gán ACADEMIC_RECORD khi gắn với PERSON_NAME/STUDENT_ID cùng văn bản, nhưng Bảng 10 lại có mức medium cho ACADEMIC_RECORD đứng một mình. Nhãn hiện tại là nhãn tạm.")
S(HT, "[[PN:Tô Gia Huy]]: [[AR:điểm môn Cấu trúc dữ liệu là 4,5 nên phải học lại]].", "academic boundary log",
  note="Cụm vị ngữ dài, có tên môn học; ranh giới span chưa có ví dụ trong hướng dẫn.")
S(HT, "[[PN:Kim Ngọc Ánh]] [[AR:được học bổng toàn phần]] năm học này, hãy viết lời chúc mừng.", "academic")
S(HT, "Nguyễn Văn A có GPA 3,2 và được học bổng loại giỏi, tính xem còn cần bao nhiêu tín chỉ.", "hard_negative sample_name")
S(HT, "Mình tên là [[PN:Khúc Văn Lợi]], thầy [[PN:Ninh Đức Hạnh]] có dạy lớp mình không nhỉ?", "honorific")
S(HT, "Nhờ AI sửa lời mở đầu: 'Kính gửi ThS. [[PN:Âu Đình Phúc]] và PGS.TS. [[PN:Kiều Quang Thái]]'.", "honorific quoted")
S(HT, "Python do Guido van Rossum tạo ra, hãy so sánh với Java về cú pháp.", "hard_negative public_figure")
S(HT, "Mình dùng Microsoft Word và Google Docs để viết báo cáo nhóm, nên chọn công cụ nào để nộp cho Phòng Đào tạo?", "hard_negative org_software")

# ============================== HÀNH CHÍNH ==============================
S(HC, "Điền đơn xin xác nhận sinh viên cho [[PN:Trịnh Văn Đạt]], CCCD [[NID:038204001234]], ở [[AD:số 5 ngõ 18 đường Nguyễn Bỉnh Khiêm, phường Lê Lợi, Hải Phòng]].", "multi_entity")
S(HC, "Hộ khẩu của em ở [[AD:thôn Đông Phú, xã Tân Hưng, huyện Vĩnh Bảo, Hải Phòng]], nhờ AI soạn đơn xin miễn giảm học phí.", "")
S(HC, "SĐT của cô [[PN:Vương Thị Hoa]] là [[PH:0987 654 321]], nhờ soạn tin nhắn nhắc lịch họp lớp.", "honorific")
S(HC, "Liên hệ [[PH:+84 903 112 233]] hoặc [[PH:091.456.7788]] nếu cần xác nhận lịch.", "phone_format")
S(HC, "Zalo của em: [[PH:84976001122]], thầy gọi giúp em.", "phone_format")
S(HC, "Số CMND cũ của bố em là [[NID:031987654]], em cần điền vào mẫu đơn trợ cấp.", "nine_digit")
S(HC, "Chuyển học phí vào STK [[BA:1903456789012]] tại ngân hàng ABC, nội dung: học phí kỳ 1.", "")
S(HC, "Em nhận học bổng qua số tài khoản [[BA:0071002233445]] ngân hàng Vietcombank, chủ tài khoản [[PN:Đỗ Mai Phương]].", "multi_entity")
S(HC, "stk: [[BA:19036677889900]]", "short")
S(HC, "CCCD [[NID:038 204 001 235]], cấp ngày 12/05/2023 tại Cục Cảnh sát QLHC.", "grouped_digits")
S(HC, "Số 450678123900 này là gì, có phải CCCD không?", "ambiguous_digits log", status="REVIEW_REQUIRED",
  note="Dãy 12 chữ số, không có từ khóa ngữ cảnh. Theo Bảng 14 chỉ gán NATIONAL_ID khi có ngữ cảnh định danh; nhãn tạm: không gán.")
S(HC, "Mã hồ sơ: 0900000000, ngày nộp 12/11, người nhận phòng Công tác sinh viên.", "hard_negative phone_like")
S(HC, "Mã biên lai học phí BL-2026-778899, số tiền 12.500.000 đồng, đã nộp ngày 05/10.", "hard_negative")
S(HC, "Tổng đài hỗ trợ sinh viên: 1800 1234, giờ làm việc 8h-17h.", "hard_negative org_contact")
S(HC, "Gửi thư tới [[EM:nguyen.hoang.nam@mail.example]] và cc [[EM:le.thu.trang@mail.example]] giúp mình, nội dung xin lùi lịch bảo vệ.", "multi_entity")
S(HC, "Tên đăng nhập: [[EM:tran.hai.yen@mail.example]], mật khẩu: [[CR:Xk9#mPq2]]. Nhờ AI hướng dẫn đổi mật khẩu.", "username_email")
S(HC, "Cổng sinh viên: tài khoản [[SID:2510334455]] / mật khẩu [[CR:Hp#tmp7781]], em bị khóa tài khoản.", "username_sid")
S(HC, "Nộp hồ sơ tại phòng Công tác sinh viên, số 171 đường Phan Đăng Lưu, phường Kiến An, Hải Phòng, trong giờ hành chính.", "hard_negative org_address")
S(HC, "Tôi sống ở Hải Phòng, năm nay học năm 3 ngành Công nghệ thông tin.", "hard_negative place_name")
S(HC, "Kính gửi thầy cô, em tên là [[PN:Lương Minh Quân]], hiện cư trú tại [[AD:số 27 đường Trần Hưng Đạo, quận Hồng Bàng, Hải Phòng]].", "street_name_inside_address")
S(HC, "Em ở [[AD:xóm 3, thôn Bắc, xã An Lão, huyện An Lão, Hải Phòng]], cách trường khoảng 25 km.", "")
S(HC, "Viết đơn xin phúc khảo, dùng giá trị mẫu: Nguyễn Văn B, MSSV 0000000000, SĐT 0123456789.", "hard_negative sample_value")
S(HC, "Sinh viên [[PN:Âu Thị Kim]], MSSV [[SID:2511009988]], [[AR:bị đình chỉ học tập một học kỳ]], cần soạn đơn xin học lại.", "academic multi_entity")
S(HC, "dia chi nha em o [[AD:so 9 pho Cat Dai, phuong Le Chan, Hai Phong]], xin nhan giay xac nhan", "no_diacritics")
S(HC, "ĐỊA CHỈ GIAO GIẤY TỜ: [[AD:TỔ 4, KHU ĐOÀN KẾT, PHƯỜNG ĐỒNG HÒA, QUẬN KIẾN AN, TP HẢI PHÒNG]]", "uppercase")
S(HC, "Mình là [[PN:Hà Duy Khương]], SĐT [[PH:0345 889 900]], email [[EM:khuong.ha@mail.example]]. Nhờ viết lại phần giới thiệu bản thân cho gọn.", "multi_entity")
S(HC, "Xác nhận CCCD [[NID:079301234567]] và số điện thoại [[PH:0765.221.334]] của phụ huynh để làm hồ sơ miễn giảm.", "multi_entity")
S(HC, "Em ghi nhầm: CCCD là [[NID:025201112233]], còn số tài khoản là [[BA:0451000112233]]. Em nên sửa thế nào?", "nid_vs_bank multi_entity")
S(HC, "Thông tin nhận tiền: [[PN:Tạ Quang Hải]], số tài khoản [[BA:5521003344556]], ngân hàng XYZ.", "multi_entity")
S(HC, "Email văn phòng khoa: vpkhoa@uni.example, số máy lẻ 214, liên hệ giờ hành chính.", "hard_negative org_contact")
S(HC, "Gửi bản scan CCCD qua [[EM:SV2512.NAM@MAIL.EXAMPLE]] trước 17h.", "uppercase")
S(HC, "Tên miền email sinh viên có dạng @uni.example, mật khẩu mặc định do nhà trường cấp. Hướng dẫn mình đăng nhập lần đầu.", "hard_negative domain_only")
S(HC, "Hợp đồng ký túc xá: [[PN:Bế Thanh Sơn]], MSSV [[SID:2512667788]], SĐT [[PH:0968 100 200]], CCCD [[NID:045202003344]], quê quán [[AD:thôn Hạ, xã Nam Sơn, huyện An Dương, Hải Phòng]].", "multi_entity five_types")
S(HC, "Họ và tên: [[PN:Doãn Thị Hồng]]\nMSSV: [[SID:CT250988]]\nSĐT: [[PH:0912 777 888]]\nĐịa chỉ: [[AD:số 3 ngõ 70 đường Chợ Con, phường Kênh Dương, Hải Phòng]]\nLý do: xin giấy xác nhận vay vốn", "multiline form multi_entity")
S(HC, "Tôi là [[PN:Quách Văn Hiếu]]. Nhờ AI tóm tắt thông báo: 'Sinh viên có mã [[SID:2511880099]] vui lòng đến phòng Đào tạo nhận quyết định.'", "quoted multi_entity")
S(HC, "Gọi giúp mình số [[PH:0906118224]] lúc 9h sáng mai.", "phone_format")
S(HC, "Số máy của bạn [[PN:Văn Thị Lệ]]: [[PH:+84 977 331 442]].", "phone_format honorific")
S(HC, "mình ở lớp CNTT6.K25, sdt [[PH:0388.552.119]], ai cần nhóm học thì liên hệ nha", "informal phone_format")
S(HC, "Liên hệ nhanh qua [[PH:0937-552-619]] nhé, mình trả lời trong giờ nghỉ trưa.", "phone_format dash")
S(HC, "so tai khoan [[BA:1020304050607]] ngan hang ABC, chu tk la [[PN:tran thi quynh]]", "no_diacritics multi_entity")
S(HC, "STK [[BA:1900 6677 8899]] (ngân hàng XYZ), nội dung chuyển khoản: tiền ăn ký túc xá.", "grouped_digits")
S(HC, "Nộp lệ phí vào tài khoản của nhà trường: số TK 3201000778899 tại ngân hàng ABC, chủ tài khoản Trường Đại học.", "hard_negative org_account",
  note="Tài khoản của đơn vị, không phải tài khoản cá nhân (Bảng 14).")
S(HC, "Căn cước công dân số [[NID:031 305 002 468]] của em cần được điền vào ô thứ 3 của biểu mẫu.", "grouped_digits")
S(HC, "CMND [[NID:142 665 331]] của em đã mất, nhờ AI soạn đơn xin cấp lại giấy xác nhận.", "nine_digit grouped_digits")
S(HC, "CCCD: [[NID:036302005577]]", "short")
S(HC, "Địa chỉ nhận hàng: [[AD:Phòng 312, ký túc xá B2, Trường Đại học Hải Phòng, Hải Phòng]]", "dorm log", status="REVIEW_REQUIRED",
  note="Ký túc xá vừa là nơi ở của cá nhân vừa thuộc địa chỉ trường; Bảng 14 loại 'địa chỉ cơ quan, trường học'. Nhãn tạm: ADDRESS.")
S(HC, "Em trọ gần chợ Hàng, đường Nguyễn Trãi, cách trường khoảng 3 km.", "partial_address log", status="REVIEW_REQUIRED",
  note="Địa chỉ không đầy đủ (không có số nhà/xã/thành phố); Bảng 14 yêu cầu chuỗi từ số nhà đến tỉnh/thành. Nhãn tạm: không gán.")
S(HC, "Phụ huynh em tên [[PN:Hoa Văn Dũng]], ở [[AD:khu 6, thị trấn Núi Đèo, huyện Thủy Nguyên, Hải Phòng]], điện thoại [[PH:0977 123 090]].", "multi_entity")

# ============================== CNTT ==============================
S(IT, ".env:\nDB_USER=admin\nDB_PASS=[[CR:Kq7!mZx4vR]]\nAPI_KEY=[[SK:sk-Qw8Er2Ty5Ui9Op1As3Df6Gh0Jk4Lz7Xc]]", "multiline env")
S(IT, "conn = psycopg2.connect(host='localhost', user='app', password='[[CR:Zq!82nLm]]')", "code quoted")
S(IT, "git remote set-url origin https://deploy:[[SK:ghp_Abc123Def456Ghi789Jkl012Mno345Pqr678]]@github.com/team/repo.git", "url_token")
S(IT, "aws_access_key_id = [[SK:AKIAIOSFODNN7EXAMPLE]]", "sample_key log", status="REVIEW_REQUIRED",
  note="Chuỗi trùng khóa ví dụ trong tài liệu của nhà cung cấp. Bảng 14 không gán giá trị mẫu, nhưng nhóm chưa có danh sách giá trị mẫu cụ thể. Nhãn tạm: SECRET_KEY.")
S(IT, "Authorization: Bearer [[SK:eyJhbGciOiJIUzI1NiJ9.eyJ1aWQiOiI3NzEifQ.c2lnbmF0dXJlX2Zha2U]]", "jwt")
S(IT, "commit a3f5c9e1b2d4f6a8c0e2a4b6c8d0e2f4a6b8c0d2 đã được merge vào nhánh main, kiểm tra giúp mình.", "hard_negative hash")
S(IT, "UUID phiên: 550e8400-e29b-41d4-a716-446655440000, server 192.168.1.15 cổng 8080, phiên bản 3.11.4.", "hard_negative uuid ip")
S(IT, "Mật khẩu root của máy ảo là [[CR:lab-Root#417]], đừng chia sẻ cho ai.", "")
S(IT, "Mã OTP của em là [[CR:482913]], hết hạn sau 5 phút, tại sao ứng dụng vẫn báo sai?", "otp")
S(IT, "Mã PIN thẻ của em là [[CR:7391]], em có nên đổi không?", "pin short_value")
S(IT, "Viết hàm kiểm tra mật khẩu mạnh: tối thiểu 8 ký tự, có chữ hoa, số và ký tự đặc biệt.", "hard_negative generic_password")
S(IT, "Sửa lỗi: Error 500 tại cổng 5432, mã lỗi 0x80070005, request_id 2026110312.", "hard_negative number_like")
S(IT, "INSERT INTO sinhvien (mssv, ho_ten, sdt) VALUES ('[[SID:2511667788]]', '[[PN:Trần Bảo Châu]]', '[[PH:0934 556 677]]');", "sql code multi_entity")
S(IT, '''{"name": "[[PN:Hồ Đức Thịnh]]", "email": "[[EM:thinh.ho@mail.example]]", "token": "[[SK:ghp_Zy9Xw8Vu7Ts6Rq5Po4Nm3Lk2Ji1Hg0Fe9Dc8]]"}''', "json code multi_entity")
S(IT, "2026-11-03 10:15:22 INFO login ok user=[[EM:khanh.vu@mail.example]] ip=10.0.0.12 session=9f1c2b7a", "log_line")
S(IT, "docker login -u student -p [[CR:Dk#2026!pass]] registry.example.com", "cli")
S(IT, "Viết regex nhận diện email dạng ten@example.com và số điện thoại dạng 0xxxxxxxxx.", "hard_negative placeholder")
S(IT, "Ví dụ mẫu: API_KEY=YOUR_API_KEY, password=<password>, user=<username>.", "hard_negative placeholder")
S(IT, "SECRET_KEY trong Django settings là '[[SK:django-insecure-8f#k2$vq9z!x1m7@w4b6n0c3y5t]]', có nên đưa lên GitHub không?", "quoted")
S(IT, "Token Slack của bot: [[SK:xoxb-1234567890-0987654321-AbCdEfGhIjKlMnOpQrStUvWx]], bot không phản hồi lệnh.", "")
S(IT, "Hey, can you debug this? My student id is [[SID:2512003344]] and the password is [[CR:Qw3rty!9z]] for the lab server.", "english multi_entity")
S(IT, "Please summarize the email from [[PN:Mai Tuấn Kiệt]] ([[EM:kiet.mai@corp.example]]) about the thesis deadline.", "english multi_entity")
S(IT, "Giải thích cách bcrypt băm mật khẩu; ví dụ hash $2b$12$abcdefghijklmnopqrstuv không phải mật khẩu thật.", "hard_negative hash")
S(IT, "mysql://root:[[CR:Pw8Lq2Zx]]@10.1.2.3:3306/qlsv — kết nối này báo lỗi access denied, sửa giúp mình.", "url_password")
S(IT, "Cổng 3306 và 5432 là cổng mặc định của MySQL và PostgreSQL, đúng không?", "hard_negative number_like")
S(IT, "docker-compose.yml:\n  environment:\n    - POSTGRES_PASSWORD=[[CR:pg-Lab#5521]]\n    - JWT_SECRET=[[SK:b7e2f91c04a8d3659e1f70ab42c8d6e3]]", "multiline yaml hex_secret log",
  note="Chuỗi 32 ký tự hex có thể bị nhầm với hash MD5; ở đây tên biến JWT_SECRET là căn cứ để gán SECRET_KEY.")
S(IT, "sha256 của file là 9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08, so khớp giúp mình.", "hard_negative hash")
S(IT, "Bài lab: đăng nhập SSH vào 10.20.30.40 với user sv01, mật khẩu [[CR:Lab@Net99]].", "")
S(IT, "Sinh viên [[PN:Nông Thị Thu]] gửi log lỗi:\nERROR auth failed for [[SID:2512445566]] from 172.16.0.8", "multiline log_line multi_entity")
S(IT, "print('Xin chào, tôi là [[PN:Phùng Đức Toàn]]')  # số điện thoại [[PH:0933 221 100]]", "code comment multi_entity")
S(IT, "Nguyen Van A đăng nhập với user=test, pass=123456 để demo chức năng đăng nhập.", "demo_password log", status="REVIEW_REQUIRED",
  note="Mật khẩu demo phổ biến (123456) đi kèm tên mẫu. Chưa rõ có tính là CREDENTIAL hay là giá trị mẫu (không gán). Nhãn tạm: không gán.")
S(IT, "Nhờ AI refactor đoạn code này:\nAPI_URL = 'https://api.example.com/v1'\nTOKEN = '[[SK:tok_live_51Hq8LmKzP0aVx3Wd7Yt2BnRc]]'", "multiline code quoted")
S(IT, "Email của giảng viên: [[EM:tran.van.binh@uni.example]] — thầy [[PN:Trần Văn Bình]] dạy môn Hệ điều hành.", "email_contains_name honorific log",
  note="Email cơ quan nhưng gắn với một cá nhân cụ thể: gán EMAIL; Bảng 14 chỉ nói 'email cá nhân' và loại email bộ phận/tổ chức, chưa nói về email công vụ của một người.")
S(IT, "Dùng dấu @ để tách email: viết hàm tách phần user và domain từ chuỗi user@domain.", "hard_negative placeholder")
S(IT, "Tạo user [[SID:2512778899]] trong LDAP với mật khẩu tạm [[CR:Ch@ngeMe2026]].", "username_sid")
S(IT, "Hướng dẫn tạo SSH key: ssh-keygen -t ed25519 -C 'email@example.com'.", "hard_negative placeholder")
S(IT, "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASC\n-----END PRIVATE KEY-----", "private_key log", status="REVIEW_REQUIRED",
  note="Khối khóa riêng tư (PEM) chưa thuộc định nghĩa SECRET_KEY (khóa API, token, JWT). Cần thống nhất có gán cả khối hay không. Nhãn tạm: không gán.")
S(IT, "Báo lỗi đăng nhập: user [[PN:Giang Thị Oanh]], email [[EM:oanh.giang@mail.example]], mật khẩu [[CR:Oa#9981x]], token [[SK:sk-Lm5Nb7Vc9Xz1Qa3Ws5Ed7Rf9Tg1Yh3U]].", "multi_entity four_types")
S(IT, "Google API key của dự án là [[SK:AIzaSyB4q8Wn2LkXc7Vd1ZtRy5PmHs3JfEa0Ugo]], có nên để trong file JS phía client không?", "")
S(IT, "Mình quên mật khẩu wifi phòng lab, nên hỏi ai và đặt mật khẩu mới thế nào cho an toàn?", "hard_negative generic_password")
S(IT, "Chạy lệnh: curl -H 'X-Api-Key: [[SK:kd8f3Lq0Zp7Wm2Vn5Tx9Yb4Rc1Ae6Hj]]' https://api.example.com/users", "cli quoted")

# ============================== BỔ SUNG CÂN BẰNG NHÃN HIẾM ==============================
S(HC, "Đơn đăng ký tạm trú: họ tên [[PN:Mạc Thị Xuân]], số CCCD [[NID:030303004455]].", "multi_entity")
S(IT, "Cột cccd trong bảng sinhvien đang lưu giá trị [[NID:092205006677]], có cần mã hóa trước khi lưu không?", "column_value")
S(HT, "Em cần điền số căn cước [[NID:031204007788]] vào phiếu đăng ký thi chứng chỉ tiếng Anh.", "")
S(HC, "Phụ huynh sẽ chuyển khoản vào số tài khoản [[BA:6010203040506]] (ngân hàng ABC) của em trong tuần này.", "")
S(HC, "TK nhận hoàn học phí: [[BA:0381000445566]] - [[PN:Lã Văn Kiên]]", "multi_entity")
S(IT, "UPDATE sinhvien SET stk='[[BA:1050607080910]]' WHERE mssv='[[SID:2512990011]]';", "sql code multi_entity")
S(HT, "Nhờ AI viết tin nhắn nhờ bạn chuyển tiền photo giáo trình vào STK [[BA:0912003456789]].", "phone_like_bank")
S(HC, "Mình ghi số tài khoản [[BA:2200 3300 4400]] vào đơn xin hỗ trợ.", "grouped_digits")
S(HT, "Bạn [[PN:Sầm Thị Nhàn]] cho mình email [[EM:nhan.sam98@mail.example]] để gửi tài liệu ôn thi.", "multi_entity")
S(IT, "git config user.email '[[EM:duc.hung.dev@mail.example]]' rồi commit lại vẫn báo lỗi author.", "code quoted")
S(HC, "Thư mời họp gửi cho [[EM:thanh.tung@corp.example]]; hỏi AI nên viết tiêu đề thế nào cho lịch sự.", "")
S(IT, "STRIPE_KEY=[[SK:sk_test_9bX2LmQw7Rt4Vn8Zc1Hd5Fa3]] đã lỡ commit lên repo công khai, phải xử lý sao?", "env")
S(IT, "export GITHUB_TOKEN=[[SK:ghp_Q1w2E3r4T5y6U7i8O9p0A1s2D3f4G5h6J7k8]]", "cli")
S(HT, "Bạn [[PN:Tiêu Văn Nam]] [[AR:được xét học bổng loại xuất sắc]] học kỳ này, soạn bài phát biểu nhận học bổng giúp mình.", "academic")
S(HT, "[[SID:2512113355]] [[AR:có điểm trung bình học kỳ 3,45]], nhờ viết thư giới thiệu thực tập.", "academic")
S(HC, "Em [[PN:Từ Mỹ Hạnh]] cần giấy xác nhận vì [[AR:bị cảnh báo học vụ mức 2]], để làm hồ sơ vay vốn.", "academic")
S(HC, "Địa chỉ thường trú của em: [[AD:số 41 phố Lý Thường Kiệt, phường Hồng Bàng, Hải Phòng]].", "")
S(HT, "Mình ở [[AD:thôn 5, xã Quang Trung, huyện Tiên Lãng, Hải Phòng]], mỗi ngày đi xe buýt 40 phút lên trường, nên chọn lịch học thế nào?", "")
S(HC, "DIA CHI: [[AD:SO 88 DUONG HOANG VAN THU, PHUONG QUANG TRUNG, HAI PHONG]]", "no_diacritics uppercase")
