#!/usr/bin/env python3
"""So sánh hai bản gán nhãn (người A và người B) trên cùng các mẫu: Cohen's kappa mức ký tự + F1 theo span.

Chạy:  python compare_annotations.py nhan_goc.jsonl nhan_nguoi_thu_hai.jsonl [--csv bat_dong.csv]
Hai tệp cần cùng "id" và "text"; chỉ khác "entities". Mục tiêu theo Mục 2.5.1: kappa ≥ 0,80.
"""
import argparse, csv, sys
from collections import Counter

from common import LABELS, read_jsonl


def char_labels(rec):
    arr = ["O"] * len(rec["text"])
    for e in rec["entities"]:
        for i in range(e["start"], e["end"]):
            arr[i] = e["label"]
    return arr


def kappa(a, b):
    n = len(a)
    po = sum(x == y for x, y in zip(a, b)) / n
    ca, cb = Counter(a), Counter(b)
    pe = sum(ca[k] * cb[k] for k in set(ca) | set(cb)) / (n * n)
    return 1.0 if pe == 1 else (po - pe) / (1 - pe)


def span_key(e):
    return (e["start"], e["end"], e["label"])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("a")
    ap.add_argument("b")
    ap.add_argument("--csv")
    args = ap.parse_args()
    A = {r["id"]: r for r in read_jsonl(args.a)}
    B = {r["id"]: r for r in read_jsonl(args.b)}
    common = sorted(set(A) & set(B))
    missing = sorted(set(A) ^ set(B))
    if missing:
        print(f"Cảnh báo: {len(missing)} id chỉ có ở một bên: {missing[:5]}...")
    chars_a, chars_b, diffs = [], [], []
    tp = fp = fn = 0
    for i in common:
        a, b = A[i], B[i]
        if a["text"] != b["text"]:
            print(f"Cảnh báo: {i} có text khác nhau, bỏ qua")
            continue
        chars_a += char_labels(a)
        chars_b += char_labels(b)
        sa, sb = {span_key(e): e for e in a["entities"]}, {span_key(e): e for e in b["entities"]}
        tp += len(set(sa) & set(sb))
        for k in set(sa) - set(sb):
            fn += 1
            other = [e for e in b["entities"] if e["start"] < k[1] and k[0] < e["end"]]
            kind = "khác nhãn" if any((e["start"], e["end"]) == k[:2] for e in other) else ("lệch ranh giới" if other else "người B bỏ sót")
            diffs.append([i, kind, "A", k[2], sa[k]["text"], ";".join(f"{e['label']}:{e['text']}" for e in other)])
        for k in set(sb) - set(sa):
            fp += 1
            other = [e for e in a["entities"] if e["start"] < k[1] and k[0] < e["end"]]
            if not other:
                diffs.append([i, "người B gán thêm", "B", k[2], sb[k]["text"], ""])
    p = tp / (tp + fp) if tp + fp else 0
    r = tp / (tp + fn) if tp + fn else 0
    f1 = 2 * p * r / (p + r) if p + r else 0
    k = kappa(chars_a, chars_b)
    print(f"Số mẫu so sánh: {len(common)}   Số ký tự: {len(chars_a)}")
    print(f"Cohen's kappa (mức ký tự, 11 lớp gồm 'O'): {k:.3f}   {'ĐẠT' if k >= 0.80 else 'CHƯA ĐẠT'} ngưỡng 0,80")
    print(f"F1 span chặt giữa hai người: {f1:.3f}  (P={p:.3f}, R={r:.3f}, TP={tp}, A-only={fn}, B-only={fp})")
    print(f"Số bất đồng cần thảo luận: {len(diffs)}")
    if args.csv:
        with open(args.csv, "w", encoding="utf-8-sig", newline="") as f:
            w = csv.writer(f)
            w.writerow(["ID mẫu", "Loại bất đồng", "Bên có", "Nhãn", "Đoạn", "Đoạn chồng lấn bên kia"])
            w.writerows(diffs)
        print(f"Đã ghi {args.csv}")


if __name__ == "__main__":
    sys.exit(main())
