#!/usr/bin/env python3
"""Sinh bộ kiểm thử độc lập từ testset_source.py: tự tính start/end, mức rủi ro, thống kê.

Chạy:  python build_testset.py --out data
Tạo:   testset_independent.jsonl / .csv, testset_stats.json, review_log.csv,
       blind_sample.csv (chỉ có text, để người thứ hai gán nhãn độc lập), blind_sample_key.jsonl
"""
import argparse, csv, json, random, re, sys
from collections import Counter
from pathlib import Path

from common import ALIAS, LABELS, compute_risk, nfc
import testset_source

MARK = re.compile(r"\[\[([A-Z]{2,3}):(.+?)\]\]", re.S)


def parse_markup(markup):
    """Trả về (text, entities) với offset tính theo code point trên văn bản NFC."""
    src = nfc(markup)
    parts, ents, pos, length = [], [], 0, 0
    for m in MARK.finditer(src):
        code, value = m.group(1), m.group(2)
        if code not in ALIAS:
            raise ValueError(f"Mã nhãn lạ [[{code}:...]] trong: {markup[:60]}")
        before = src[pos:m.start()]
        parts.append(before)
        length += len(before)
        ents.append({"start": length, "end": length + len(value), "label": ALIAS[code], "text": value})
        parts.append(value)
        length += len(value)
        pos = m.end()
    parts.append(src[pos:])
    return "".join(parts), ents


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="data")
    ap.add_argument("--seed", type=int, default=2026)
    ap.add_argument("--blind", type=int, default=40, help="số mẫu đưa vào bộ gán nhãn mù cho người thứ hai")
    args = ap.parse_args()
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    records = []
    for i, s in enumerate(testset_source.SAMPLES, 1):
        text, ents = parse_markup(s["markup"])
        tags = s["tags"]
        rec = {
            "id": f"H{i:03d}",
            "split": "test_indep",
            "scenario": s["scenario"],
            "template_id": f"HW-{i:03d}",
            "text": text,
            "entities": ents,
            "risk_level": compute_risk(ents),
            "has_sensitive": bool(ents),
            "no_diacritics": "no_diacritics" in tags,
            "review_status": s["status"],
            "labeler": "TV3",
            "reviewer": "",
            "difficulty_tags": tags,
            "note": s["note"],
        }
        records.append(rec)

    with open(out / "testset_independent.jsonl", "w", encoding="utf-8", newline="\n") as f:
        for r in records:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")

    csv_cols = ["id", "split", "scenario", "template_id", "text", "entities", "risk_level",
                "has_sensitive", "no_diacritics", "review_status", "labeler", "reviewer", "difficulty_tags", "note"]
    with open(out / "testset_independent.csv", "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=csv_cols)
        w.writeheader()
        for r in records:
            row = dict(r)
            row["entities"] = json.dumps(r["entities"], ensure_ascii=False)  # giữ đủ start/end/label/text
            row["difficulty_tags"] = " ".join(r["difficulty_tags"])
            w.writerow(row)

    # nhật ký trường hợp khó: mẫu REVIEW_REQUIRED hoặc có thẻ "log"
    with open(out / "review_log.csv", "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(["ID mẫu", "Văn bản", "Đoạn/nhãn đang gán", "Trạng thái", "Lý do / quy tắc cần cập nhật", "Quyết định cuối"])
        for r in records:
            if r["review_status"] == "REVIEW_REQUIRED" or "log" in r["difficulty_tags"]:
                lab = "; ".join(f"{e['text']} → {e['label']}" for e in r["entities"]) or "(không gán)"
                w.writerow([r["id"], r["text"], lab, r["review_status"], r["note"], ""])

    # thống kê
    reviewed = [r for r in records if r["review_status"] != "REVIEW_REQUIRED"]
    lab_all = Counter(e["label"] for r in records for e in r["entities"])
    lab_final = Counter(e["label"] for r in reviewed for e in r["entities"])
    tag_cnt = Counter(t for r in records for t in r["difficulty_tags"])
    stats = {
        "n_samples": len(records),
        "n_entities": sum(lab_all.values()),
        "n_samples_review_required": len(records) - len(reviewed),
        "n_entities_in_review_required": sum(lab_all.values()) - sum(lab_final.values()),
        "scenario": dict(Counter(r["scenario"] for r in records)),
        "risk_level": {k: Counter(r["risk_level"] for r in records).get(k, 0) for k in ["none", "low", "medium", "high"]},
        "with_entities": sum(1 for r in records if r["entities"]),
        "without_entities": sum(1 for r in records if not r["entities"]),
        "hard_negative": tag_cnt.get("hard_negative", 0),
        "no_diacritics": sum(1 for r in records if r["no_diacritics"]),
        "uppercase": tag_cnt.get("uppercase", 0),
        "english": tag_cnt.get("english", 0),
        "multiline": tag_cnt.get("multiline", 0),
        "entities_per_label_all": {l: lab_all.get(l, 0) for l in LABELS},
        "entities_per_label_excl_review": {l: lab_final.get(l, 0) for l in LABELS},
        "avg_len": round(sum(len(r["text"]) for r in records) / len(records), 1),
        "min_len": min(len(r["text"]) for r in records),
        "max_len": max(len(r["text"]) for r in records),
        "tags": dict(tag_cnt.most_common()),
    }
    (out / "testset_stats.json").write_text(json.dumps(stats, ensure_ascii=False, indent=2), encoding="utf-8")

    # bộ gán nhãn mù: chọn mẫu bảo đảm phủ đủ 10 nhãn rồi bổ sung ngẫu nhiên (seed cố định)
    rng = random.Random(args.seed)
    pool = [r for r in records if r["review_status"] != "REVIEW_REQUIRED"]
    chosen = {}
    for lab in LABELS:
        cands = [r for r in pool if any(e["label"] == lab for e in r["entities"]) and r["id"] not in chosen]
        if cands:
            r = rng.choice(cands)
            chosen[r["id"]] = r
    negatives = [r for r in pool if not r["entities"] and r["id"] not in chosen]
    for r in rng.sample(negatives, min(6, len(negatives))):
        chosen[r["id"]] = r
    rest = [r for r in pool if r["id"] not in chosen]
    for r in rng.sample(rest, max(0, args.blind - len(chosen))):
        chosen[r["id"]] = r
    blind = sorted(chosen.values(), key=lambda r: r["id"])
    with open(out / "blind_sample.jsonl", "w", encoding="utf-8", newline="\n") as f:
        for r in blind:  # file đưa cho người thứ hai: chỉ có id + text, entities rỗng để họ điền
            f.write(json.dumps({"id": r["id"], "text": r["text"], "entities": []}, ensure_ascii=False) + "\n")
    with open(out / "blind_sample_key.jsonl", "w", encoding="utf-8", newline="\n") as f:
        for r in blind:  # nhãn gốc để so sánh (KHÔNG đưa cho người thứ hai)
            f.write(json.dumps({"id": r["id"], "text": r["text"], "entities": r["entities"]}, ensure_ascii=False) + "\n")

    print(f"Đã tạo {len(records)} mẫu, {stats['n_entities']} thực thể -> {out}/")
    for l in LABELS:
        print(f"  {l:16s} {stats['entities_per_label_all'][l]:3d}  (không tính REVIEW_REQUIRED: {stats['entities_per_label_excl_review'][l]})")


if __name__ == "__main__":
    sys.exit(main())
